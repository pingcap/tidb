`github.com/cznic/mathutil` has moved to [`modernc.org/mathutil`](https://godoc.org/modernc.org/mathutil) ([vcs](https://gitlab.com/cznic/mathutil)).

Please update your import paths to `modernc.org/mathutil`.

This repo is now archived.

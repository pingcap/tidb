Instructions
============

Install the package with:

    go get github.com/pingcap/check
    
Import it with:

    import "github.com/pingcap/check"

and use _check_ as the package name inside the code.


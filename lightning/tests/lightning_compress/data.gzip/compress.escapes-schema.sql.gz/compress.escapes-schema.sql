/*!40101 SET NAMES binary*/;
CREATE TABLE `escapes` (
  `i` int(11) NOT NULL,
  `t` text DEFAULT NULL,
  `j` json DEFAULT NULL,
  `b` blob DEFAULT NULL,
  PRIMARY KEY (`i`) /*T![clustered_index] CLUSTERED */
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

/*!40101 SET NAMES binary*/;
CREATE TABLE `multi_rows` (
  `a` varchar(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
